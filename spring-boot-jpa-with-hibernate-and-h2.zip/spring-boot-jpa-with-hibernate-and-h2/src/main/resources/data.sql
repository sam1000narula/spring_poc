insert into student
values(10001,'manish', 'A1234568');

insert into student
values(10002,'Samarth', 'A1234569');

insert into employee
values(1,'2017-11-15','Samarth', 'Full Stack Developer');

insert into employee
values(2,'2019-03-11','Shakil', 'Full Stack Developer');

insert into users
values(1,'admin', 'admin');

insert into users
values(2,'samarth', '123456');

insert into users
values(3,'shakil', '123456');
